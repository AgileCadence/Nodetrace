﻿
function Get-SyncEngineConnectionString([string]$sqlServer, [string]$sqlUser, [string]$sqlPwd, [string]$sqlDB)
{
    return "Data Source=$sqlServer; " +
        "Integrated Security=False; " +
        "User Id=$sqlUser; " +
        "Password='`"$sqlPwd`"'; " +
        "Initial Catalog=$sqlDB"
}

function Get-SanitizedSyncEngineArguments([string]$arguments)
{
    return $arguments -replace "Password='`".+?`"'", "Password='`"*************`"'"
}

function Invoke-DbSyncPreReq([string]$LogDir, [string]$metadataDirectory, [string]$connectionstring, [bool]$useLegacyIds)
{
    $webroot = Get-AosWebSitePhysicalPath
    [xml]$web = Get-Content "$($webroot)\web.config"

    Write-Output 'Update Web.Config file - set Safe Mode On'
    ($web.configuration.appSettings.add | where key -eq 'Aos.SafeMode' | select -First 1).Value  = 'True'
    $web.Save("$($webroot)\web.config")

    #Sync Engine - Pre Req

    $command = Join-Path $metadataDirectory "Bin\SyncEngine.exe"
    $syncMode = "additivetablesync"
    if ($useLegacyIds)
    {
        $syncMode = "additivetablesync,legacyids"
    }
    
    # Unique indexes are always ignored in additive mode. Additionally, the following non-unique indexes should be ignored for performance reasons.
    $ignoreNonUniqueIndexListArg = "-IgnoreIndexList=GeneralJournalAccountEntry.ColumnStoreIdx,HRMInjuryIncidentCostType.LineNumIdx,HRMInjuryIncidentTreatment.LineNumIdx,ProjEmplTrans.EmplDateIdx,RetailCDXUploadSession.LocalUploadSessionIdIdx,RetailCDXUploadSession.UploadSessionRerunIdx,RetailDlvModeProductLine.DlvModeLineNumIdx,RetailTillLayoutZone.LayoutZoneIdx,TSTimesheetTable.ResourcePeriodIdx,TSTimesheetTableLog.ResourcePeriodIdx"

    $arguments = "-syncmode=$syncMode $ignoreNonUniqueIndexListArg -metadatabinaries=$metadataDirectory -connect=`"$connectionstring`" -verbosity=`"Diagnostic`""

    #Sync Engine - Additive Table Sync
    Write-Output 'Starting SyncEngine to trigger additive tables sync'
    Write-Output $command (Get-SanitizedSyncEngineArguments $arguments)

    $additiveSyncLogFile = "$LogDir\additivesync.log"
    $additiveSyncErrorFile = "$LogDir\additivesync.error.log"

    $process = Start-Process $command -ArgumentList $arguments -PassThru -Wait -RedirectStandardOutput $additiveSyncLogFile -RedirectStandardError $additiveSyncErrorFile
        
    # Adding new syncMode to SyncEngine is not fully backwards compatable as old versions of the exe throw an argument exception
    # Checking if the parameter -syncmode=additivetablesync is not understood by SyncEngine and ignoring.
    $additiveSyncLog = Get-Content $additiveSyncLogFile
    $additiveSyncError = Get-Content $additiveSyncErrorFile

    if (($process.ExitCode -ne 0) -and (($additiveSyncLog| %{$_ -match 'System.ArgumentException: Invalid sync mode argument -syncmode=additivetablesync'}) -contains $true))
    {
        Clear-Content $additiveSyncErrorFile
        Clear-Content $additiveSyncLogFile
        Write-Output "Parameter -syncmode=additivetablesync is not recognised by this version of SyncEngine. Skipping additive table sync."
    }

    #Sync Engine - Partial sync of select tables + kernel sync
    $syncList = "BATCHJOBRECURRENCECOUNT,BATCHJOBACTIVEPERIOD,BATCH,BATCHHISTORY,BATCHJOB,BATCHJOBHISTORY,EVENTCUD,EVENTCUDLINES,INTEGRATIONACTIVITYRUNTIMETABLE,RELEASEUPDATECHANGETRACKINGTABLES,RELEASEUPDATECONFIGURATION,RELEASEUPDATEDISABLEDINDEXES,RELEASEUPDATESCRIPTDEPENDENCY,RELEASEUPDATESCRIPTS,RELEASEUPDATESCRIPTSERRORLOG,RELEASEUPDATESCRIPTSLOG,RELEASEUPDATESCRIPTSUSEDTABLES,RELEASEUPDATEVERSIONS,SYSDATABASELOG,SYSDATABASELOGLINES,SYSDATACACHECONFIGURATIONTABLE,SYSDATACHANGEDETECTIONEVENTTABLE,SYSDATASHARINGFOREIGNKEYTABLE,SYSDATASHARINGISSUES,SYSDATASHARINGORGANIZATION,SYSDATASHARINGORGANIZATIONENABLED,SYSDATASHARINGPOLICY,SYSDATASHARINGPOLICYSTAGING,SYSDATASHARINGRULE,SYSDATASHARINGRULEENABLED,SYSDATASHARINGRULEISSUES,SYSDATASHARINGTABLEFIELD,SYSDATASHARINGTABLEFIELDENABLED,SYSDATASHARINGTESTFKINKEY,SYSDATASHARINGTESTFOREIGNKEYTABLE,SYSDATASHARINGTESTTABLE,SYSFLIGHTING,SYSUSERINFO,SYSUSERLOG,USERGUID,USERINFO,SYSCLIENTPERF,SYSTEMJOBPARAMETERS"

    $syncMode = "partiallist"
    if ($useLegacyIds)
    {
        $syncMode = "partiallist,legacyids"
    }

    $arguments = "-syncmode=$syncMode -synclist=$syncList -metadatabinaries=$metadataDirectory -connect=`"$connectionstring`" -verbosity=`"Diagnostic`""

    Write-Output 'Starting SyncEngine to trigger the kernal tables sync and partial sync of select system tables'
    Write-Output $command (Get-SanitizedSyncEngineArguments $arguments)

    $partialSyncLogFile = "$LogDir\partialsync.log"
    $partialSyncErrorFile = "$LogDir\partialsync.error.log"

    $process = Start-Process $command -ArgumentList $arguments -PassThru -Wait -RedirectStandardOutput $partialSyncLogFile -RedirectStandardError $partialSyncErrorFile

    #Update Web.Config file - set Safe Mode Off
    [xml]$web = Get-Content "$($webroot)\web.config"
    ($web.configuration.appSettings.add | where key -eq 'Aos.SafeMode' | select -First 1).Value  = 'False'
    $web.Save("$($webroot)\web.config")

    if ($additiveSyncError -ne $null)
    {
        Write-Error 'Failed pre requisities for running the data upgrade. Please fix the issues in the error log and retry the step'
        throw $additiveSyncError
    }

    $partialSyncError = Get-Content $partialSyncErrorFile
    if (($process.ExitCode -ne 0) -or $partialSyncError -ne $null)
    {
        Write-Error 'Failed pre requisities for running the data upgrade. Please fix the issues in the error log and retry the step'
        throw $partialSyncError
    }
}

Export-ModuleMember -Function *

# SIG # Begin signature block
# MIIjkAYJKoZIhvcNAQcCoIIjgTCCI30CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAA9lEgUr/o1Y+9
# PZl/k/ZJxhCtclo8R+yEgufc+lNgLKCCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZTCCFWECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgtGFOLXWx
# 5k3kkUht72idJ6qiWEMX8djibk2r94MJtkUwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQCU25cilE6DwNL6Qsv2v1exDNjllU/rH90T9K2VbREV
# pYH5A2b7Xy4UHBorqbw10Clr57pVxzcxM28K8qImcEp/2w33sOapvKydK7LSNP70
# KpcfMFJz0oNBFS7J7Uz/eREGdutGGItkVm07NtS1Cguy9hpz2epKZ/ib6UouKNMn
# vhP4DXnrIdceTWIwCwyYu2KOY8yHACgJVb7XsRBzYi1CNUXh8AwYVc3JdZzxQiK2
# aSP9AvkOyMilzGYJEV8q417AgoexWCl2IEiWUAJ6MwtroDfROfzEPDcR9BPBAJqV
# w6Sf70lzs5OluC4+4gVnaDtBsIDMemgqeJLPzptYPwEroYIS7zCCEusGCisGAQQB
# gjcDAwExghLbMIIS1wYJKoZIhvcNAQcCoIISyDCCEsQCAQMxDzANBglghkgBZQME
# AgEFADCCAVQGCyqGSIb3DQEJEAEEoIIBQwSCAT8wggE7AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIAF6iMvU9i6qsSqJqz1VmLs9GD6eeb3VJlvQEJFC
# RgTuAgZe8gJE220YEjIwMjAwNjIzMjExMDE0LjkyWjAEgAIB9KCB1KSB0TCBzjEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWlj
# cm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBU
# U1MgRVNOOjBBNTYtRTMyOS00RDREMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1T
# dGFtcCBTZXJ2aWNloIIOQzCCBPUwggPdoAMCAQICEzMAAAEnL26j75GoGagAAAAA
# AScwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAw
# HhcNMTkxMjE5MDExNDU5WhcNMjEwMzE3MDExNDU5WjCBzjELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJh
# dGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjBBNTYt
# RTMyOS00RDREMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+AHecRGeTp9LjS+9Z4Pc
# cKAz0SnjFMhCI+clcT0T4eRlW1Ow96ag7KF80DIX3kT+tS9c5VNRwkUvtdvXqNMo
# 9c42wJZjwMKLFIMiKJ3rFrfROIRZVwhlHCIOVzHb0Pjrs5Nq/msDUbpPAARjmtCO
# FQcus6gmB8l9qRmrogeN36yUjT+qXKztAgZqQWTY4HqaH+Wf+dLwbiQ1EroOjiDE
# O2cFIUs1+GxJmVFIwMnAW+tnYUKRqh7F3usqVQ04ABJxjjXUgSpB4jU/B9GbdpZt
# Lwi8B8k8LYCHYuu0/ywqfl9ppTx6l7GN7u9l9xmJ/9xvGBQpK0nOpt29ME1z3ef9
# nwIDAQABo4IBGzCCARcwHQYDVR0OBBYEFOX0llWAXzkxJFtiU4lduFjTbZXyMB8G
# A1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeG
# RWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Rp
# bVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUH
# MAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3Rh
# UENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYB
# BQUHAwgwDQYJKoZIhvcNAQELBQADggEBAArKjXzRVccGpWeNnBDLs2XNdujb5bmp
# 8fFHsA1XlEGRGR0ZqaTBRwM0v4Okc5sU8kdrShN5goTRluXUy+99LxG0YZ2EZgYI
# l/4E93+AEKzj52Rl2O87M3K5W4M8aWpDl/sdLuK5D9wLIYdwdgnSddV7AXYuT4mW
# tbKQelOUvA9eYKk1H6CJ4i0+L9QwXZFhMbCiNb7IhXA3IxieMUZTERfn8O0mNFma
# Ds8EcysQ03YOA7rAF6Wnim3IfYorYSxZP7yMUK6gq/54lvLRAPnks3l/xKtQ9Gcr
# zp+HtpU58KCVCh+jkAFkgaIMiuDgmxXiTqnSgFIgU4BypECGIf7WykIwggZxMIIE
# WaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0y
# NTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RU
# ENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBE
# D/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50
# YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd
# /XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaR
# togINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQAB
# o4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8
# RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIB
# hjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fO
# mhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggr
# BgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSAB
# Af8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEF
# BQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBt
# AGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Eh
# b7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7
# uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqR
# UgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9
# Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8
# +n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+
# Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh
# 2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRy
# zR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoo
# uLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx
# 16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341
# Hgi62jbb01+P3nSISRKhggLRMIICOgIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjBB
# NTYtRTMyOS00RDREMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloiMKAQEwBwYFKw4DAhoDFQCzlbhObIMcxEzuLPqaAaiOq9cfM6CBgzCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA
# 4pyAwDAiGA8yMDIwMDYyMzE3MjMxMloYDzIwMjAwNjI0MTcyMzEyWjB2MDwGCisG
# AQQBhFkKBAExLjAsMAoCBQDinIDAAgEAMAkCAQACAS4CAf8wBwIBAAICEc8wCgIF
# AOKd0kACAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQAC
# AwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQAKxcfRuOlHqqsZMsPG
# PeZZ+aDg1eKeNRLO03lL+w9zu8A57r2iGP+P7UynOy4K5XZz736KbY1WfmEnO/aH
# YD/sXuSe0oCn5mifS0m28JEWGx/89h11tPAk2t4U1PF5kjddvIYXh3Cch156Rcpb
# 3zQMYfl+Kd1MCjfV5xqLMPdx1DGCAw0wggMJAgEBMIGTMHwxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFBDQSAyMDEwAhMzAAABJy9uo++RqBmoAAAAAAEnMA0GCWCGSAFlAwQC
# AQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkE
# MSIEIJXF/884Inp8WwIZ4VfmstT8/oW/BMkHnoF4H4Uzh8+PMIH6BgsqhkiG9w0B
# CRACLzGB6jCB5zCB5DCBvQQgG5LoSxKGHWoW/wVMlbMztlQ4upAdzEmqH//vLu0j
# PiIwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAScv
# bqPvkagZqAAAAAABJzAiBCApJXBwrjMCACbta1Q3WWubKwsWVDfsV3eqzlo/PYpY
# BTANBgkqhkiG9w0BAQsFAASCAQDNf3UewCC9f6mR1G5Yjkpa5y5ygaC+TNs3cehK
# BnOk4OQpBAy6LN521ZKQKvhgEiwPHBEWP2hCHSh49fPL+BMT34Ffjysdf0fdQfGZ
# WOmrCUNKqPbFQJgVZzAmNMCwRkQK5LZkpBC3y4QzW0RXNqbidsEpQjWClhkeGUll
# yePu+JSCHWDVBTnv3Q5Z6ta2JeM8zpr68r0olPz+8rSacCfQ4KHHX06r5tiSItO7
# ZP6YqG1iVk0ozL3FHCzoSHbXN8SWXKx9s01fi5P0D5ZyoY+EMN2EBW89ZsNAuT+v
# afwPr7mUj+gPV4QUbAThQMiHzVRLnje7i1oDJCUNBPDJOlsN
# SIG # End signature block
