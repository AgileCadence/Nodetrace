#######################################################
###              Restore Admin Account             ####
#######################################################

PARAM (
    [Parameter(Mandatory=$true)]
    $log
)

# Import modules and initialize the log
Import-Module WebAdministration
Import-Module "$PSScriptRoot\CommonRollbackUtilities.psm1" -DisableNameChecking
Import-Module "$PSScriptRoot\AosCommon.psm1" -Force -DisableNameChecking
Initialize-Log $log

try
{
    Write-Log "Restore Admin Account: Start"
    $error.Clear()

    $webroot = Get-AosWebSitePhysicalPath
    $webrootBinPath = Join-Path $webroot 'bin'
    $environmentDllPath = Join-Path $webrootBinPath 'Microsoft.Dynamics.ApplicationPlatform.Environment.dll'
    Add-Type -Path $environmentDllPath

    # Load application configuration
    $config = [Microsoft.Dynamics.ApplicationPlatform.Environment.EnvironmentFactory]::GetApplicationEnvironment()

    # Initialize db variables
    $target_DatabaseInstance = $($config.DataAccess.DbServer)     # i.e. localhost
    $target_DatabaseName     = $($config.DataAccess.Database)     # i.e. AxDBRAIN
    $target_DatabaseUserName = $($config.DataAccess.SqlUser)      # i.e. axdbadmin
    $target_DatabasePassword = $($config.DataAccess.SqlPwd)

    $target_sqlParams = @{
        'Database'       = $($target_DatabaseName)
        'UserName'       = $($target_DatabaseUserName)
        'Password'       = $($target_DatabasePassword)
        'ServerInstance' = $($target_DatabaseInstance)
        'Query'          = ''
        'QueryTimeout'   = 0 }

    $webroot = Get-AosWebSitePhysicalPath
    Write-Log "The Service drive path of the webroot on the aos machine is : $webroot"

    $TenandId = $($config.Aad.AADTenantId)
    $AdminPrincipalName = $($config.Provisioning.AdminPrincipalName)
    $AdminIdentityProvider = $($config.Provisioning.AdminIdentityProvider)  

    if ($AdminPrincipalName -eq $null)
    {
        throw "Admin principal name in web.config is null so stopping restore of Admin account. Please check Admin account in DB manually and update the web.config for Admin principal name."
    }
    else
    {
        if ($AdminIdentityProvider -eq $null)
        {
            $AdminIdentityProvider = 'https://sts.windows.net/'
        }

        $target_sqlParams.Database = $target_DatabaseName

        $target_sqlParams.Query = @"
        SELECT COUNT(*) As Ct FROM USERINFO WHERE ID = 'Admin'
"@
        $count = Invoke-Sqlcmd @target_sqlParams
        Write-Log "Number of admin users are $($count.Ct)"

        # Validate if ADMIN account is unique.
        if($count.Ct -gt 1)
        {
            Write-Log "Multiple admin records found. Removing duplicates."
            $target_sqlParams.Query = @"
            DECLARE @expectedCnt int = 0,
            @adminPrincipalName varchar(100) = '$AdminPrincipalName'
                SELECT @expectedCnt = COUNT(*) FROM USERINFO WHERE ID = 'Admin' and NETWORKALIAS = @adminPrincipalName;
        
                        IF @expectedCnt >= 1 
                        BEGIN
                            DELETE USERINFO WHERE ID = 'Admin' and NETWORKALIAS != @adminPrincipalName;
                            IF @expectedCnt > 1 
                            BEGIN
                                DELETE TOP(@expectedCnt - 1) USERINFO WHERE ID = 'Admin'
                            END;
                        END;

                        ELSE
                        BEGIN
                            DELETE TOP($($count.Ct) - 1) USERINFO WHERE ID = 'Admin'
                        END;
"@
            Invoke-Sqlcmd @target_sqlParams | out-null
            Write-Log "Removed the duplicate Admin records."
        }
        else
        {
            Write-Log "No duplicate Admin records found in USERINFO table."
        }
                
        $target_sqlParams.Query = @"
        SELECT COUNT(*) As Ct FROM USERINFO WHERE ID = 'Admin'
"@
        $currentCount = Invoke-Sqlcmd @target_sqlParams
        Write-Log "Number of current admin users are $($currentCount.ct)"

        # Validate if ADMIN account exists.
        if($currentCount.Ct -eq 0)
        {
            Write-Log "USERINFO has empty Admin account. Need to create Admin account."
            $target_sqlParams.Query = @"
            DECLARE 
            @expectedAdminSID varchar(1000) = '',
            @adminIdentityProviderDef varchar(100) = '$AdminIdentityProvider',
            @adminPrincipalName varchar(100) = '$AdminPrincipalName'
            IF @expectedAdminSID = '' or @expectedAdminSID = NULL
            BEGIN
                SET @expectedAdminSID = '$expectedAdminSID'
            END;
        
            BEGIN
                INSERT INTO USERINFO (ID, NAME, ENABLE, STATUSLINEINFO, TOOLBARINFO, DEBUGINFO, AUTOINFO, AUTOUPDATE, GARBAGECOLLECTLIMIT, HISTORYLIMIT, MESSAGELIMIT, GENERALINFO, SHOWSTATUSLINE, SHOWTOOLBAR, SHOWAOTLAYER, CONFIRMDELETE, REPORTFONTSIZE, FORMFONTSIZE, PROPERTYFONTSIZE, COMPANY, COMPILERWARNINGLEVEL, SID, NETWORKDOMAIN, NETWORKALIAS, LANGUAGE, HELPLANGUAGE, PREFERREDTIMEZONE, NOTIFYTIMEZONEMISMATCH, ACCOUNTTYPE, DEFAULTPARTITION, INTERACTIVELOGON)  
                VALUES ('Admin', 'Admin', 1, -538365, -1, 12, -1, 6, 20, 5, 1000, -8209, 1, 1, 4, -1, 9, 9, 9, 'DAT', 3, @expectedAdminSID, @adminIdentityProviderDef, @adminPrincipalName, 'en-US', 'en-us', 58, 1, 2, 1, 1)
            END;
"@
            Invoke-Sqlcmd @target_sqlParams | out-null
            Write-Log "Added a new admin record to USERINFO table."
        }
        else
        {
            Write-Log "Validated that Admin account exists."
            
            # Chek if db has duplicated network alias account
            $target_sqlParams.Query = @"
            SELECT	ENABLE,
                    NETWORKALIAS,
                    IDENTITYPROVIDER,
                    NETWORKDOMAIN,
                    SID 
            FROM USERINFO WHERE ID = 'Admin'
"@
            $adminDb = Invoke-Sqlcmd @target_sqlParams
              
            # Validate if admin is the same provisioning admin and has the same domain with the tenant
            if (($TenandId -ne $null) -and ($adminDb.NETWORKALIAS -ne $null) -and ((($adminDb.NETWORKALIAS).SubString($adminDb.NETWORKALIAS.IndexOf('@')+1)).ToUpper() -ne $TenandId.ToUpper()))
            {
                Write-Log "Admin in USERINFO has the different domain with the tenant."
            }

            $adminDbNetworkAlias = $adminDb.NETWORKALIAS
            if($adminDbNetworkAlias -eq $AdminPrincipalName)
            {
                Write-Log "Validated that admin network alias is the same with the admin principal name in the config."
                
                # Check if db has duplicate networkalias with admin account
                $target_sqlParams.Query = @"
                SELECT COUNT(*) As Ct FROM USERINFO WHERE NETWORKALIAS = '$AdminPrincipalName'
"@
                $count = Invoke-Sqlcmd @target_sqlParams
                Write-Log "Number of admin networkalias users are $($count.Ct)"

                # Validate if ADMIN networkalias account duplicated.
                if($count.Ct -gt 1)
                {
                    $target_sqlParams.Query = @"
                    DELETE USERINFO WHERE NETWORKALIAS = '$AdminPrincipalName' AND ID != 'Admin' 
"@
                    Invoke-Sqlcmd @target_sqlParams | out-null
                    Write-Log "Removed the non Admin records."
                }
            }
            else
            {
                Write-Log "Admin network alias in USERINFO is different with default provisioning admin principal name."
                
                # Update id of current admin account to different id
                $target_sqlParams.Query = @"
                UPDATE USERINFO set ID =  '$adminDbNetworkAlias' WHERE ID = 'Admin'
"@
                Invoke-Sqlcmd @target_sqlParams | Out-Null
                Write-Log "Updated id of duplicated Admin account."
                                                
                $target_sqlParams.Query = @"
                SELECT	ENABLE,
                        ID
                FROM USERINFO WHERE NETWORKALIAS = '$AdminPrincipalName'
"@
                $adminPrincipal = Invoke-Sqlcmd @target_sqlParams
                
                # Validate if there is non admin account in USERINFO has same NETWORKALIAS with default provisioning admin principal name.
                If($adminPrincipal -ne $null)
                {
                    # Remove duplicated records if it has
                    $target_sqlParams.Query = @"
                    SELECT COUNT(*) As Ct FROM USERINFO WHERE NETWORKALIAS = '$AdminPrincipalName'
"@
                    $adminPrincipalCount = Invoke-Sqlcmd @target_sqlParams
                    Write "Number of admin principal records are $($adminPrincipalCount.Ct)"
                    $adminPrincipalCnt = $adminPrincipalCount.Ct

                    # Validate if ADMIN networkalias account duplicated.
                    if($adminPrincipalCnt -gt 1)
                    {
                        $target_sqlParams.Query = @"
                        DELETE TOP(@adminPrincipalCnt - 1) FROM USERINFO WHERE NETWORKALIAS = '$AdminPrincipalName' 
"@
                        Invoke-Sqlcmd @target_sqlParams | out-null
                        Write "Removed the non Admin records."
                    }

                    # Enable and update id of the user with networkalias of admin principal name to 'Admin' 
                    $target_sqlParams.Query = @"
                    UPDATE USERINFO set Enable = 1, ID = 'Admin' WHERE NETWORKALIAS = '$AdminPrincipalName'
"@
                    Invoke-Sqlcmd @target_sqlParams | Out-Null
                    Write-Log "Updated id of duplicated Admin account."
                }
                else
                {
                    # Insert new record of Admin account
                    $target_sqlParams.Query = @"
                    DECLARE 
                    @expectedAdminSID varchar(1000) = '',
                    @adminIdentityProviderDef varchar(100) = '$AdminIdentityProvider',
                    @adminPrincipalName varchar(100) = '$AdminPrincipalName'
                    IF @expectedAdminSID = '' or @expectedAdminSID = NULL
                    BEGIN
                        SET @expectedAdminSID = '$expectedAdminSID'
                    END;
    
                    BEGIN
                            INSERT INTO USERINFO (ID, NAME, ENABLE, STATUSLINEINFO, TOOLBARINFO, DEBUGINFO, AUTOINFO, AUTOUPDATE, GARBAGECOLLECTLIMIT, HISTORYLIMIT, MESSAGELIMIT, GENERALINFO, SHOWSTATUSLINE, SHOWTOOLBAR, SHOWAOTLAYER, CONFIRMDELETE, REPORTFONTSIZE, FORMFONTSIZE, PROPERTYFONTSIZE, COMPANY, COMPILERWARNINGLEVEL, SID, NETWORKDOMAIN, NETWORKALIAS, LANGUAGE, HELPLANGUAGE, PREFERREDTIMEZONE, NOTIFYTIMEZONEMISMATCH, ACCOUNTTYPE, DEFAULTPARTITION, INTERACTIVELOGON)  
                            VALUES ('Admin', 'Admin', 1, -538365, -1, 12, -1, 6, 20, 5, 1000, -8209, 1, 1, 4, -1, 9, 9, 9, 'DAT', 3, @expectedAdminSID, @adminIdentityProviderDef, @adminPrincipalName, 'en-US', 'en-us', 58, 1, 2, 1, 1)
                    END;
"@
                    Invoke-Sqlcmd @target_sqlParams | out-null
                    Write-Log "Added a new admin record to USERINFO table to has the same account with admin principal name."
                }
            }
            
            # Get admin account
            $target_sqlParams.Query = @"
            SELECT	ENABLE,
                    NETWORKALIAS,
                    IDENTITYPROVIDER,
                    NETWORKDOMAIN,
                    SID 
            FROM USERINFO WHERE ID = 'Admin'
"@
            $adminDb = Invoke-Sqlcmd @target_sqlParams

            #Validate if Admin is enabled
            If($adminDb.ENABLE -ne 1)
            {
                Write-Log "Admin account is disabled. Enabling Admin account."
                $target_sqlParams.Query = @"
                UPDATE USERINFO set ENABLE = 1 WHERE ID = 'Admin'
"@
                Invoke-Sqlcmd @target_sqlParams | Out-Null
                Write-Log "Finished enabling ADMIN account."
            }
            else
            {
                Write-Log "Validated that admin account is enabled."    
            }

            # Validate if SID is correct.
            Write-Log "Loading the  Microsoft.Dynamics.AX.Security.SidGenerator.dll file to generate SID."
            $expectedAdminSID = $null

            $dllPath = Join-Path $webroot '\bin\Microsoft.Dynamics.AX.Security.SidGenerator.dll'
            if (Test-Path $dllPath)
            {
                [Reflection.Assembly]::LoadFile($dllPath)
                $expectedAdminSID = [Microsoft.Dynamics.Ax.Security.SidGenerator]::Generate($AdminPrincipalName, $AdminIdentityProvider)
            }

            if ($expectedAdminSID -eq $null)
            {
                Write-Log "Expected admin SID is null so no check for admin SID."
            }
            else
            {
                Write-Log "Value retrieved for Expected Admin SID: $($expectedAdminSID)"

                if($adminDb.SID -ne $expectedAdminSID)
                {   
                    Write-Log "SID is not valid, current SID: $($adminDb.SID)"
                    $target_sqlParams.Query = @"
                    DECLARE @expectedAdminSID varchar(1000) = ''
                    SET @expectedAdminSID = '$expectedAdminSID'	
                    UPDATE USERINFO set SID = @expectedAdminSID WHERE ID = 'Admin'
"@
                    Invoke-Sqlcmd @target_sqlParams | Out-Null
                    Write-Log "Finsihed updating the SID."				
                }
                else
                {
                    Write-Log "SID is valid."
                }
            
                # Validate if Admin network domain is correct
                If ($adminDb.NETWORKDOMAIN -ne $AdminIdentityProvider.ToUpper())
                {
                    Write-Log "Admin network domain in USERINFO is different with default provisioning admin identity provider"
                    $target_sqlParams.Query = @"
                    DECLARE @adminIdentityProviderDef varchar(100) = '$AdminIdentityProvider'
                    UPDATE USERINFO set NETWORKDOMAIN = @adminIdentityProviderDef WHERE ID = 'Admin'
"@
                    Write-Log "Updated admin network domain in USERINFO."
                    Invoke-Sqlcmd @target_sqlParams | Out-Null
                }
                else
                {
                    Write-Log "Admin network domain is correct."
                }
            }
        }
    }
}
Catch
{
	# Write the exception and that this process failed.  
	# Do not throw as this should not cause the deployment or update to fail.
    Write-Exception $_       
    Write-Log "Restore Admin Account failed, see $log for details."
}
Finally
{
    Write-Log "Restore Admin Account: Stop"
}

# SIG # Begin signature block
# MIIjkQYJKoZIhvcNAQcCoIIjgjCCI34CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCACMQzv+CZ12qIP
# Fn9xihYUhmi6kbEQWA+AzfhaShOTrKCCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZjCCFWICAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgVzqPggLH
# pxVrzyhzmeXNaBIGEZ9d12S4umwt+0/EGdcwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQCyTPEO2I2kx7d6iS5Mfz8Uud0PGqihavdfYtdqOfNF
# fjNLWIqLuiFzgn3wKMSa8RTKrCtNEEz8lQ55WnYDqL9J6v9xwlyJDZh2dp85VNEE
# YvimJfP+22esFKk4Jn/3P5OdrSSBr3AYMcDmMYhaoXfaymHQkoXGSyxwK/9BF/Fg
# BlSwaozMmgC3zeGF+cem8aSYmpOGqaa01uH8hftDUbIye/wn981Ibrpgi7fDEmwu
# b0SywSTQxL6x9aK1g8BDhLwJv7WxAqpx3uNWP/MurUy/raZu88dkNpMIOghSSjCS
# KdPof2Pn88TI6p8eVuq/LVLbgVfIbfHXGkig+HSSS84MoYIS8DCCEuwGCisGAQQB
# gjcDAwExghLcMIIS2AYJKoZIhvcNAQcCoIISyTCCEsUCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIDct3WfGJV3bC3n+3CsqdGpgIkr/FS/aBJppFxBY
# rtchAgZe8gJ/J64YEzIwMjAwNjIzMjExMDE1LjQ2NFowBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjo3ODgwLUUzOTAtODAxNDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkMwggT1MIID3aADAgECAhMzAAABKKAOgeE21U/CAAAA
# AAEoMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTE5MTIxOTAxMTUwMFoXDTIxMDMxNzAxMTUwMFowgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo3ODgw
# LUUzOTAtODAxNDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJ2Rsdb3VNuGPs2/Dgpc
# 9gt77LG0JPkD4VWTlEJLkqznTJl+RoZfiOwN6iWfPu4k/kj8nwY7pvLs1OsBy494
# yusg4rHLwHNUJPtw1Tc54MOLgdcosA4Nxki73fDyqWwDtjOdk6H7kNczBPqADD6B
# 98ot77/wSACBJIxm9qAUudquS5fczCF0++aWUavDu46U3cv6HEjIdV2ZdJTUKg4W
# UIdTYMQXI082+qSs45WBZjcK98/tIfx8uq8q8ksWF9+zUjGTFiMaKHhn7cSCoEj7
# E1tVmW08ISpS678WFP2+A0OQwaWcJKNACK+J+La7Lz2bGupCidOGz5XDewc1lD9n
# LPcCAwEAAaOCARswggEXMB0GA1UdDgQWBBSE4vKD8X61N5vUAcNOdH9QBMum8jAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQCLX2ZHGIULgDk/iccHWUywjDyAsBHl
# hkmtmBp4lldwL3dNo0bXZZHiSZB+c2KzvPqY64BlECjS/Pqur2m9UaT1N0BeUowR
# HQT88wdzd94gYqKXmLDbVR8yeVgBkcP/JiVWbXdQzcz1ETHgWrh+uzA8BwUgAaHJ
# w+nXYccIuDgPJM1UTeNl9R5Ovf+6zR2E5ZI4DrIqvS4jH4QsoMPTn27AjN7VZt4a
# moRxMLEcQAS7vPT1JUUaRFpFHmkUYVln1YMsw///6968aRvy3cmClS44uxkkaILb
# hh1h09ejZjHhrEn+k9McVkWiuY724jJ/57tylM7A/jzIWNj1F8VlhkyyMIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0TCCAjoCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo3
# ODgwLUUzOTAtODAxNDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAMT1LG/KAEj0XsiL9n7mxmX1afZuggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOKcgP4wIhgPMjAyMDA2MjMxNzI0MTRaGA8yMDIwMDYyNDE3MjQxNFowdjA8Bgor
# BgEEAYRZCgQBMS4wLDAKAgUA4pyA/gIBADAJAgEAAgENAgH/MAcCAQACAhGQMAoC
# BQDindJ+AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEA
# AgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAIVmkP9VAAdA5s6br
# GUlTtPtGzdKUD8lzssB1tvVq5qb8QgBlAuMxeQYKUIusxoizn4h54IT9deDVCKuI
# hlWSyaV0EzjagKEOSxmiTC/cL7/4ySsaggxATRsMwWaSIB0mYrfbjetnL+mt8SRb
# SkCrTASHzaduYTKT33K5NrK128gxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMAITMwAAASigDoHhNtVPwgAAAAABKDANBglghkgBZQME
# AgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJ
# BDEiBCCHD0N4r9BxM2x5iE8zZpANRm3KHNvv7FwHy3kGmDNutTCB+gYLKoZIhvcN
# AQkQAi8xgeowgecwgeQwgb0EILxFaouvBVJ379wbEN8GpLhvW09eGg8WsLrXm9XW
# 6BTaMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAEo
# oA6B4TbVT8IAAAAAASgwIgQgQMcqmBB+DmDI+y8RxCPptDMIhudvlWFIZ9vEFAwP
# rCEwDQYJKoZIhvcNAQELBQAEggEAV0/8OrRmmJKHK4H8x5X8zDDuopZECO0u2tpp
# +kVN9GNgDieslxsX8goVcvKWlGbdlVuMI8f/64RkMtYmrmO1z494jDMSa+5wYCk2
# loWeVgm4qMiyS/kcP0lERNK7QFTVa0XjHxHaw+HHjDM6IZKoxBfvCdvqGlRTMRg2
# foxXdumqFv3GH6bKzgMkC5qkQl7hQZHR/gMs8+e+rBpryACr2+J4gqrsSTu9lzP4
# XrYTSmpOtnIkfurebKZNeRnyfhfFpBUKnguFyk5DSDfIz6gJkNge8g1jSBYVudLV
# DAxDZ92oJegCMxTi0COKU7xzkwGpFcykMgs5g1mR4LL5Cwh9RQ==
# SIG # End signature block
